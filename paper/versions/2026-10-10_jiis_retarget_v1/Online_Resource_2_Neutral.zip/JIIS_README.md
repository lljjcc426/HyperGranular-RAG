# JIIS numerical resource

Neutral public copy; author metadata is supplied in the private submission archive.

Run python reconstruct.py. Saved-score reconstruction only; no answer rescoring or additional tests. README.md retains the original numerical-package scope.
